//
//  projectMain.hpp
//  CSCI-2270
//
//  Created by 蒋新宇 on 2018/5/3.
//  Copyright © 2018年 XInyu JIang. All rights reserved.
//

#ifndef projectMain_hpp
#define projectMain_hpp

#include <stdio.h>

#endif /* projectMain_hpp */
